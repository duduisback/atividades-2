/*
Eduardo Rodrigues Lima de Oliveira
Desenvolvimento de aplicações
TCTG241CNTDEV
*/
public class NumerosResto5 {
    public static void main(String[] args) {
        System.out.println("Números entre 1 e 1000 que, ao serem divididos por 11, dão resto 5:");
        for (int i = 1; i <= 1000; i++) {
            if (i % 11 == 5) {
                System.out.println(i);
            }
        }
    }
}
