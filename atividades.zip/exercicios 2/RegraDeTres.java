/*
Eduardo Rodrigues Lima de Oliveira
Desenvolvimento de aplicações
TCTG241CNTDEV
*/
import java.util.Scanner;

public class RegraDeTres {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double valor1, valor2, valor3;
        char continuar;

        do {
            System.out.print("Digite o valor 1: ");
            valor1 = scanner.nextDouble();
            System.out.print("Digite o valor 2: ");
            valor2 = scanner.nextDouble();
            System.out.print("Digite o valor 3: ");
            valor3 = scanner.nextDouble();

            double resultado = (valor2 * valor3) / valor1;
            System.out.println("Resultado da regra de três: " + resultado);

            System.out.print("Deseja calcular novamente? (s/n): ");
            continuar = scanner.next().charAt(0);
        } while (continuar == 's' || continuar == 'S');

        System.out.println("Saindo...");
    }
}
