/*
Eduardo Rodrigues Lima de Oliveira
Desenvolvimento de aplicações
TCTG241CNTDEV
*/
import java.util.Random;
import java.util.Scanner;

public class Adivinhacao {
    public static void main(String[] args) {
        Random random = new Random();
        int numeroEscolhido = random.nextInt(100) + 1; // Número aleatório entre 1 e 100
        Scanner scanner = new Scanner(System.in);
        int palpite;

        System.out.println("Adivinhe o número escolhido (entre 1 e 100):");

        do {
            palpite = scanner.nextInt();

            if (palpite < numeroEscolhido) {
                System.out.println("MAIOR");
            } else if (palpite > numeroEscolhido) {
                System.out.println("MENOR");
            }
        } while (palpite != numeroEscolhido);

        System.out.println("ACERTOU!");
    }
}
