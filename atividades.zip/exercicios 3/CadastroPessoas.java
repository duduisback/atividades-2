/*
Eduardo Rodrigues Lima de Oliveira
Desenvolvimento de aplicações
TCTG241CNTDEV
*/
import java.util.Scanner;

public class CadastroPessoas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[][] cadastro = new String[100][3]; // Matriz para armazenar ID, Nome e Data
        int contador = 0;
        int opcao;

        do {
            System.out.println("1. Inserir pessoa");
            System.out.println("2. Alterar dados da pessoa");
            System.out.println("3. Consultar dados da pessoa");
            System.out.println("4. Excluir dados de uma pessoa");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Consumir nova linha

            switch (opcao) {
                case 1: // Inserir pessoa
                    if (contador < 100) {
                        System.out.print("ID: ");
                        cadastro[contador][0] = scanner.nextLine();
                        System.out.print("Nome: ");
                        cadastro[contador][1] = scanner.nextLine();
                        System.out.print("Data de Nascimento (dd/mm/aaaa): ");
                        cadastro[contador][2] = scanner.nextLine();
                        contador++;
                    } else {
                        System.out.println("Cadastro cheio!");
                    }
                    break;
                case 2: // Alterar dados
                    System.out.print("Digite o ID da pessoa a ser alterada: ");
                    String idAlterar = scanner.nextLine();
                    for (int i = 0; i < contador; i++) {
                        if (cadastro[i][0].equals(idAlterar)) {
                            System.out.print("Novo Nome: ");
                            cadastro[i][1] = scanner.nextLine();
                            System.out.print("Nova Data de Nascimento: ");
                            cadastro[i][2] = scanner.nextLine();
                            break;
                        }
                    }
                    break;
                case 3: // Consultar dados
                    System.out.print("Digite o ID da pessoa: ");
                    String idConsultar = scanner.nextLine();
                    for (int i = 0; i < contador; i++) {
                        if (cadastro[i][0].equals(idConsultar)) {
                            System.out.println("ID: " + cadastro[i][0]);
                            System.out.println("Nome: " + cadastro[i][1]);
                            System.out.println("Data de Nascimento: " + cadastro[i][2]);
                            break;
                        }
                    }
                    break;
                case 4: // Excluir dados
                    System.out.print("Digite o ID da pessoa a ser excluída: ");
                    String idExcluir = scanner.nextLine();
                    for (int i = 0; i < contador; i++) {
                        if (cadastro[i][0].equals(idExcluir)) {
                            for (int j = i; j < contador - 1; j++) {
                                cadastro[j] = cadastro[j + 1];
                            }
                            cadastro[contador - 1] = null; // Limpar último elemento
                            contador--;
                            break;
                        }
                    }
                    break;
                case 5:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 5);
    }
}
