/*
Eduardo Rodrigues Lima de Oliveira
Desenvolvimento de aplicações
TCTG241CNTDEV
*/
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class VetorNumeros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numeros = new int[10];
        Random random = new Random();

        // Inserir 10 números aleatórios no vetor
        for (int i = 0; i < 10; i++) {
            numeros[i] = random.nextInt(100); // Números aleatórios entre 0 e 99
        }

        // a. Lista com os números obtidos
        System.out.println("Números obtidos:");
        for (int num : numeros) {
            System.out.print(num + " ");
        }
        System.out.println();

        // b. Lista com os números ordenados em ordem crescente
        Arrays.sort(numeros);
        System.out.println("Números em ordem crescente:");
        for (int num : numeros) {
            System.out.print(num + " ");
        }
        System.out.println();

        // c. Lista com os números ordenados em ordem decrescente
        System.out.println("Números em ordem decrescente:");
        for (int i = numeros.length - 1; i >= 0; i--) {
            System.out.print(numeros[i] + " ");
        }
        System.out.println();
    }
}
