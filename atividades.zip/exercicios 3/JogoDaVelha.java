/*
Eduardo Rodrigues Lima de Oliveira
Desenvolvimento de aplicações
TCTG241CNTDEV
*/
import java.util.Scanner;

public class JogoDaVelha {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char[][] tabuleiro = {{' ', ' ', ' '}, {' ', ' ', ' '}, {' ', ' ', ' '}};
        char jogador = 'X';
        boolean jogoAtivo = true;
        int nivelDificuldade;

        System.out.print("Escolha a dificuldade (1: Normal, 2: Difícil): ");
        nivelDificuldade = scanner.nextInt();

        while (jogoAtivo) {
            mostrarTabuleiro(tabuleiro);
            if (jogador == 'X') {
                System.out.print("Jogador, digite sua jogada (linha e coluna): ");
                int linha = scanner.nextInt();
                int coluna = scanner.nextInt();
                if (tabuleiro[linha][coluna] == ' ') {
                    tabuleiro[linha][coluna] = jogador;
                    jogador = 'O';
                } else {
                    System.out.println("Posição ocupada! Tente novamente.");
                }
            } else {
                jogadaComputador(tabuleiro, nivelDificuldade);
                jogador = 'X';
            }
            if (verificarVencedor(tabuleiro)) {
                mostrarTabuleiro(tabuleiro);
                System.out.println("Jogador " + (jogador == 'X' ? "O" : "X") + " ganhou!");
                jogoAtivo = false;
            } else if (verificarEmpate(tabuleiro)) {
                mostrarTabuleiro(tabuleiro);
                System.out.println("Empate!");
                jogoAtivo = false;
            }
        }
    }

    public static void mostrarTabuleiro(char[][] tabuleiro) {
        System.out.println("Tabuleiro:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(tabuleiro[i][j]);
                if (j < 2) System.out.print(" | ");
            }
            System.out.println();
            if (i < 2) System.out.println("---------");
        }
    }

    public static void jogadaComputador(char[][] tabuleiro, int nivelDificuldade) {
        // Jogo normal
        if (nivelDificuldade == 1) {
            Random random = new Random();
            int linha, coluna;
            do {
                linha = random.nextInt(3);
                coluna = random.nextInt(3);
            } while (tabuleiro[linha][coluna] != ' ');
            tabuleiro[linha][coluna] = 'O';
        } else {
            // Jogo difícil (minimax ou lógica simples para ganhar)
            // Implementação simplificada para garantir uma jogada válida
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (tabuleiro[i][j] == ' ') {
                        tabuleiro[i][j] = 'O';
                        if (verificarVencedor(tabuleiro)) return; // Ganha se possível
                        tabuleiro[i][j] = ' '; // Desfaz a jogada
                    }
                }
            }
            jogadaComputador(tabuleiro, 1); // Se não ganhou, joga normalmente
        }
    }

    public static boolean verificarVencedor(char[][] tabuleiro) {
        for (int i = 0; i < 3; i++) {
            if (tabuleiro[i][0] != ' ' && tabuleiro[i][0] == tabuleiro[i][1] && tabuleiro[i][1] == tabuleiro[i][2])
                return true;
            if (tabuleiro[0][i] != ' ' && tabuleiro[0][i] == tabuleiro[1][i] && tabuleiro[1][i] == tabuleiro[2][i])
                return true;
        }
        if (tabuleiro[0][0] != ' ' && tabuleiro[0][0] == tabuleiro[1][1] && tabuleiro[1][1] == tabuleiro[2][2])
            return true;
        if (tabuleiro[0][2] != ' ' && tabuleiro[0][2] == tabuleiro[1][1] && tabuleiro[1][1] == tabuleiro[2][0])
            return true;
        return false;
    }

    public static boolean verificarEmpate(char[][] tabuleiro) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (tabuleiro[i][j] == ' ') return false;
            }
        }
        return true;
    }
}
